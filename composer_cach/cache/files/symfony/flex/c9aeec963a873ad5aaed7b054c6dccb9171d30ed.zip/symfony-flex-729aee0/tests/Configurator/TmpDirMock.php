<?php

namespace Symfony\Flex\Configurator;

function getcwd()
{
    return sys_get_temp_dir();
}
