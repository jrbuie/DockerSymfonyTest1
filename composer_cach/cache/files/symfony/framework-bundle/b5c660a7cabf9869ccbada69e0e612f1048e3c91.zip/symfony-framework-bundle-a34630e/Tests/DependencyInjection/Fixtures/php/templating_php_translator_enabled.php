<?php

$container->loadFromExtension('framework', array(
    'translator' => true,
    'templating' => array(
        'engines' => array('php'),
    ),
));
