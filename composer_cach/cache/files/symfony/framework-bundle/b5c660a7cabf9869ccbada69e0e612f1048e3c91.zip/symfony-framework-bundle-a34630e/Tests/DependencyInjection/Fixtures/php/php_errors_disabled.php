<?php

$container->loadFromExtension('framework', array(
    'php_errors' => array(
        'log' => false,
        'throw' => false,
    ),
));
