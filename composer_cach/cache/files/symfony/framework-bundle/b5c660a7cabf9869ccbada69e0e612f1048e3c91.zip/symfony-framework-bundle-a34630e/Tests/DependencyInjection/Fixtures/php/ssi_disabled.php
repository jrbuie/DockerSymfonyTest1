<?php

$container->loadFromExtension('framework', array(
    'ssi' => array(
        'enabled' => false,
    ),
));
