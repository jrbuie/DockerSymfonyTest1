<?php

$container->loadFromExtension('framework', array(
    'esi' => array(
        'enabled' => false,
    ),
));
