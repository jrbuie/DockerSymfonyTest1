<?php

$container->loadFromExtension('framework', array(
    'validation' => array(
        'email_validation_mode' => 'html5',
    ),
));
