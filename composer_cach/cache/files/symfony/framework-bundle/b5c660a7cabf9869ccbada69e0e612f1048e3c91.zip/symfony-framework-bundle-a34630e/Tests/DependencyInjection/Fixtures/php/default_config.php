<?php

$container->loadFromExtension('framework', array());
