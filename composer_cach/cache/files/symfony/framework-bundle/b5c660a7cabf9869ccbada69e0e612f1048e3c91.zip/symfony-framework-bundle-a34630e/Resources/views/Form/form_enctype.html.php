<?php if ($form->vars['multipart']): ?>enctype="multipart/form-data"<?php endif ?>
